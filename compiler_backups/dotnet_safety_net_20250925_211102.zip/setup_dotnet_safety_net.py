#!/usr/bin/env python3
# .NET Safety Net Setup Script
import os
import subprocess
from pathlib import Path

def setup_dotnet_safety_net():
    print("🔷 .NET Safety Net Setup")
    print("=" * 40)
    
    embedded_dir = Path("embedded_tools")
    embedded_dir.mkdir(exist_ok=True)
    
    # .NET versions for Windows
    dotnet_versions = {
        'sdk_8_0': 'https://download.visualstudio.microsoft.com/download/pr/dotnet-sdk-8.0.0-win-x64.zip',
        'sdk_7_0': 'https://download.visualstudio.microsoft.com/download/pr/dotnet-sdk-7.0.0-win-x64.zip',
        'sdk_6_0': 'https://download.visualstudio.microsoft.com/download/pr/dotnet-sdk-6.0.0-win-x64.zip',
        'runtime_8_0': 'https://download.visualstudio.microsoft.com/download/pr/dotnet-runtime-8.0.0-win-x64.zip',
        'runtime_7_0': 'https://download.visualstudio.microsoft.com/download/pr/dotnet-runtime-7.0.0-win-x64.zip',
        'aspnet_8_0': 'https://download.visualstudio.microsoft.com/download/pr/aspnetcore-runtime-8.0.0-win-x64.zip'
    }
    
    print("📥 .NET versions to download:")
    for version, url in dotnet_versions.items():
        print(f"  • {version}: {url}")
    
    # Create Windows launcher
    windows_launcher = '''@echo off
REM .NET Safety Net Launcher for Windows
set DOTNET_ROOT=embedded_tools\dotnet_sdk_8_0
set PATH=%DOTNET_ROOT%;%PATH%

REM Try different .NET versions
if exist "embedded_tools\dotnet_sdk_8_0" (
    set DOTNET_ROOT=embedded_tools\dotnet_sdk_8_0
    set PATH=%DOTNET_ROOT%;%PATH%
    echo ✅ Using .NET 8.0
) else if exist "embedded_tools\dotnet_sdk_7_0" (
    set DOTNET_ROOT=embedded_tools\dotnet_sdk_7_0
    set PATH=%DOTNET_ROOT%;%PATH%
    echo ✅ Using .NET 7.0
) else if exist "embedded_tools\dotnet_sdk_6_0" (
    set DOTNET_ROOT=embedded_tools\dotnet_sdk_6_0
    set PATH=%DOTNET_ROOT%;%PATH%
    echo ✅ Using .NET 6.0
)

REM Execute .NET command
%*
'''
    
    with open(embedded_dir / "dotnet_launcher.bat", 'w') as f:
        f.write(windows_launcher)
    
    # Create Unix launcher
    unix_launcher = '''#!/bin/bash
# .NET Safety Net Launcher
export DOTNET_ROOT="embedded_tools/dotnet_sdk_8_0"
export PATH="$DOTNET_ROOT:$PATH"

# Try different .NET versions
VERSIONS=("dotnet_sdk_8_0" "dotnet_sdk_7_0" "dotnet_sdk_6_0")

for version in "${VERSIONS[@]}"; do
    if [ -d "embedded_tools/$version" ]; then
        export DOTNET_ROOT="embedded_tools/$version"
        export PATH="$DOTNET_ROOT:$PATH"
        echo "✅ Using .NET version: $version"
        break
    fi
done

# Execute .NET command
exec "$@"
'''
    
    with open(embedded_dir / "dotnet_launcher.sh", 'w') as f:
        f.write(unix_launcher)
    os.chmod(embedded_dir / "dotnet_launcher.sh", 0o755)
    
    print("✅ .NET launcher scripts created")
    print("🎉 .NET Safety Net setup complete!")

if __name__ == "__main__":
    setup_dotnet_safety_net()
