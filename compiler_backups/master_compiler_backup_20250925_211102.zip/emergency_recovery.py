#!/usr/bin/env python3
# Emergency Compiler Recovery Script
import os
import zipfile
import json
from pathlib import Path

def restore_from_backup(backup_path, restore_dir="restored_compilers"):
    print(f"🔄 Restoring from backup: {backup_path}")
    
    restore_path = Path(restore_dir)
    restore_path.mkdir(exist_ok=True)
    
    with zipfile.ZipFile(backup_path, 'r') as zipf:
        zipf.extractall(restore_path)
        
        if 'metadata.json' in zipf.namelist():
            with zipf.open('metadata.json') as f:
                metadata = json.load(f)
                print(f"📋 Backup Type: {metadata.get('backup_type', 'Unknown')}")
                print(f"📅 Created: {metadata.get('created', 'Unknown')}")
                print(f"📝 Description: {metadata.get('description', 'No description')}")
    
    print(f"✅ Restored to: {restore_path}")
    return restore_path

def main():
    print("🚨 Emergency Compiler Recovery")
    print("=" * 40)
    
    backup_dir = Path("compiler_backups")
    if not backup_dir.exists():
        print("❌ No backup directory found")
        return
    
    backups = list(backup_dir.glob("*.zip"))
    if not backups:
        print("❌ No backup files found")
        return
    
    print("📦 Available Backups:")
    for i, backup in enumerate(backups, 1):
        size = backup.stat().st_size / (1024 * 1024)  # MB
        print(f"  {i}. {backup.name} ({size:.1f} MB)")
    
    if backups:
        latest_backup = backups[0]
        print(f"\n🔄 Restoring latest backup: {latest_backup.name}")
        restore_from_backup(latest_backup)
        print("✅ Emergency recovery complete!")

if __name__ == "__main__":
    main()
